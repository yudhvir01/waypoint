import{C as e,D as t,E as n,b as r,f as i,g as a,p as o,s,x as c}from"./index-Du0i2g5y.js";import{n as l,t as u}from"./frontMatter-Ct_F--A0.js";var d=t(n(),1),f=/<h2[^>]*>TL;DR<\/h2>\s*(<ul>[\s\S]*?<\/ul>)/;function p(e){return e.replace(f,`<div class="not-prose my-6 rounded-lg border border-primary/25 bg-primary/5 px-5 py-4"><p class="text-xs font-semibold uppercase tracking-wider text-primary">TL;DR</p><div class="tldr mt-2 text-[15px] leading-relaxed [&_li]:mt-1.5 [&_li]:ml-4 [&_li]:list-disc [&_strong]:font-semibold [&_code]:rounded [&_code]:bg-muted [&_code]:px-1 [&_code]:text-[13px]">$1</div></div>`)}var m=`---
title: Welcome
---
# Welcome

## TL;DR

- Waypoint is a logbook for what you're learning and building: **tracks**
  hold **topics**, topics hold **tasks**.
- Each morning **Today** helps you pick up to three tasks; each evening you
  write one line about what moved. Those lines become each track's trail.
- Waypoint has no database of its own. Use it as a **guest** (this browser
  only), with **your own Supabase project**, or with **Google Drive**.
- Notes, flashcards, search, review, repeating tasks, a focus timer, quick add
  and export sit around that core, each with its own chapter.

Waypoint is a logbook for everything you're learning and building. Each morning
you pick up to three things to do. Each evening you write one line about what
moved. Those lines become the trail on every track: where it's headed, where
you are, and how far you've come.

## How it's different

Most note apps (Notion, Obsidian) give you a blank page and a thousand templates.
Waypoint gives you three things and nothing else:

- **Tracks** — a subject you're working on (C++, Robotics, Interview Prep, a side
  project — whatever you're actually juggling).
- **Topics** — a unit inside a track (e.g. "Pointers", "ROS basics"), with a
  status: not started, in progress, or done.
- **Tasks** — the actual next actions inside a topic, each with an optional
  priority and due date.

**Today** opens the day: it suggests what most needs you (what's overdue, what's
due soon, what you've flagged) and you pick up to three. At the end of the day,
it asks for one line. The chapter **Your Day and the Trail** covers both.

**Tap any task** on Today and it opens right there, without taking you to its
track: the whole title (which you can edit, so a long one is never a problem),
its priority, deadline and repeat, its notes to write in, and a **Focus on
this** button that starts the timer on it.

## Archiving and deleting

**Archive** a track (the button on its page) and it leaves the sidebar and Focus
Now but nothing is lost: **Archived** at the bottom of the sidebar lists it, and
**Unarchive** brings it back. Once you're sure you're done, **Delete…** there
removes it permanently, with its topics and tasks. It asks first and says how
many tasks go. Notes you wrote on its tasks are kept as standalone notes, and
the focus time you logged stays in your totals. A track has to be archived
before it can be deleted, which is the safety.

## Your data is yours

Waypoint doesn't have a database of its own. The login screen offers three ways to
use it:

- **Guest** — no account, nothing to set up. Your notes are saved only in this
  browser's local storage, which is easy to lose (clearing site data, a private
  window, a different device all mean starting over).
- **Supabase** — you connect a project *you* create and control; your notes live
  there, not on anyone else's server, and follow you to any device you sign into.
- **Google** — saves into a "Waypoint" folder in your own Drive. Only that folder is ever touched, never the rest of your Drive.

## More than a task list

Around those three things, Waypoint is also a notebook and a place to look back:

- **Notes** that sit inside a task or stand alone, with images, audio, link
  previews and \`[[links]]\` between notes, tasks, topics and tracks.
- **Flashcards** made by writing \`question :: answer\` in a note, reviewed in
  short daily sessions.
- **Search** across everything, **Review** (what slipped, what's gone quiet,
  what's coming), **repeating tasks** and a **focus timer**.
- **Add a task**: press **C** or tap **+ Add a task**, write a line, and the date, repeat and priority are
  picked out of it.
- **Export and backup**, so nothing is stuck inside the app.

Each of those has its own chapter in this guide.

## Finding your way around

The first time you open Waypoint, the welcome screen explains the idea in
three steps and offers **Try a sample track**: a short track where each task
is one thing to try (picking a task for today, starting a focus timer,
writing the day's line, linking notes, making a flashcard). Archive it from
its page when you're done.

Every place in the app is in the menu: **Today**, **Search**, **Flashcards**,
**Review your week**, **Start a focus timer**, your tracks and your notes.
Buttons say what they do in words (**+ Today**, **▶ Focus**, **Not today**),
and the first time you open Today, a track or a note, a short tip explains
what you can do there. **Got it** hides it for good on that device.

## Get it on your phone

Waypoint installs like an app on Android and iPhone, with an Android app that
updates itself. The chapter **On Your Phone** has the steps.

Guest mode is there to try Waypoint out. The next chapter walks through the
Supabase setup for anyone who wants their notes to actually last — and if you've
already been using guest mode, Settings has a one-click "Move to Supabase" that
imports everything you've added.
`,h=`---
title: Connecting Your Supabase Project
---
# Connecting Your Supabase Project

## TL;DR

- Create a free project at supabase.com.
- Paste \`supabase/setup.sql\` into its **SQL Editor** and run it.
- Copy the **Project ID** and the **anon / public** key (never the
  \`service_role\` key).
- In Waypoint, paste both into **Connect your Supabase project**, then create
  your account.
- On every other device, connect the same project and log in with the same
  account.

Waypoint's login screen offers three ways in: try it as a guest with no setup (your
data stays only in that browser), sign in with Google (your data lives in a
Waypoint folder in your own Drive), or connect your own
[Supabase](https://supabase.com) project — a real Postgres database, under your
account, that only your Waypoint app talks to. Google and Supabase both follow you
across devices; guest mode doesn't.

This chapter covers that last option. It takes about five minutes, once. Already
using guest mode? Settings has a "Move to Supabase" button that walks you through
this same setup and then imports everything you've already added.

## 1. Create a Supabase project

1. Go to [supabase.com](https://supabase.com) and sign up (free, no card required
   for the free tier).
2. Click **New project**.
3. Give it a name (e.g. "waypoint-tracker"), set a database password (save it
   somewhere — you won't need it for the app, but it's good practice to keep it),
   and pick the region closest to you.
4. Wait for the project to finish provisioning — usually under two minutes.

## 2. Run the setup script

Waypoint ships with one SQL file, \`supabase/setup.sql\`, that creates every table it
needs and locks them down so only you can read or write your own data.

1. In your new Supabase project, open **SQL Editor** in the left sidebar.
2. Click **New query**.
3. Open \`supabase/setup.sql\` from the Waypoint repository, copy the whole file, and
   paste it into the query editor.
4. Click **Run**.

You should see a success message. If you ever want to double-check it worked, open
**Table Editor** — you should see \`tracks\`, \`topics\`, \`tasks\`, and \`topic_counts\`
listed. It also creates a public \`attachments\` bucket (for images/audio you attach
to a note), which shows up under **Storage**, not Table Editor.

The script is safe to run more than once, so if you update Waypoint later, just
paste the newest version of the file in and run it again. It brings an existing
database up to date — adding columns, indexes and helper functions — without
touching the tracks and tasks you've already written.

**Optional — link previews on paste:** pasting a bare URL into a note only turns
into a preview card (title, description, image) if \`supabase/functions/link-preview\`
is deployed. From the repository, with the [Supabase CLI](https://supabase.com/docs/guides/cli)
linked to your project: \`supabase functions deploy link-preview --no-verify-jwt\`.
It's stateless and needs no secrets. Skipping this just leaves pasted links as
plain links — nothing else in the app depends on it.

This function isn't tied to whoever's connected project it lives on — the app
calls it the same way regardless of which backend someone's using. If you're
running your own deployment of Waypoint (not just using it against your own
data), deploy it to the project behind \`VITE_SUPABASE_URL\` (or set
\`VITE_LINK_PREVIEW_URL\` to point at wherever you deployed it) so link previews
work for every visitor, including guest and Google Drive users, who have no
Supabase project of their own to deploy it to. Deploying it only to *your own*
bring-your-own project makes it work for you, in Supabase mode, and no one
else.

## 3. Get your project ID and anon key

1. In Supabase, open **Project Settings → General** and copy the **Project ID**
   (also called the project ref — a string like \`qmhmosjgokreigmsaklx\`). It's also
   the subdomain of your project URL: \`https://<project-id>.supabase.co\`.
2. Open **Project Settings → API Keys** and copy the **anon / public** key (a long
   string starting with \`eyJ...\`, or \`sb_publishable_...\` on newer projects). This
   key is safe to use in a browser app — it only grants the access your row-level
   security policies allow, which is: you can only ever see your own rows.

Do **not** use the \`service_role\` / secret key here — that key bypasses all
security rules and should never be pasted into a client app.

## 4. Connect Waypoint

1. Open Waypoint. On first run it'll show **Connect your Supabase project**.
2. Paste in the Project ID and anon key from step 3. Waypoint builds the full
   project URL for you.
3. Click **Connect**. Waypoint checks that it can reach your project and that the
   setup script ran successfully before saving anything.
4. You'll land on the sign-up screen — create an account (this is your own
   account, inside your own Supabase project, separate from your Supabase login).

That's it. Your Project ID and anon key are saved only in your browser — Waypoint
never sends them anywhere else, and every device you use (phone, laptop) just
needs the same project ID and key to see the same data.

## Using more than one device

To use Waypoint on your phone as well as your laptop, open Waypoint on the phone and go
through the same **Connect your Supabase project** step with the same project ID
and anon key. Then log in with the same account. Both devices now read and write
the same Supabase project, so changes sync automatically.
`,g=`---
title: The Markdown Import Format
---
# The Markdown Import Format

## TL;DR

- Write a whole track as Markdown and import it in one go: **+ Add track →
  Paste a plan**.
- \`#\` is the track, any heading with list items under it is a topic, and every
  bullet is a task (\`- [x]\` means already done).
- Tag tasks with \`#priority:high\`, \`#due:2026-09-10\` and \`#repeat:weekly\`.
- No file yet? **Copy AI prompt** in the import box and paste it into any AI
  chat. It asks a few questions (goal, deadline, time, habits), then writes a
  track you paste straight back, chat and all.
- You always see a preview with warnings before anything is created.

Instead of clicking through the UI to build out a whole track by hand, you can
write it as a plain Markdown file and import it in one go — useful if you're
bringing in an existing Obsidian note, or you just think better in a text editor.

The importer is intentionally simple, but it's built to survive a real,
messy roadmap file — nested headings, plain bullet lists, code blocks, the
works — not just a clean toy example.

## The basic shape

\`\`\`markdown
# Track Name
Optional free-text description line(s) before the first heading with list
items under it become the track description.

## Topic Title
- [ ] Task text #priority:high #due:2026-09-10
- [x] Completed task (already done)
- Task with no checkbox also works, and starts as not done
\`\`\`

## The rules

- **The first \`#\` heading is the track name.** Required, and it must come
  first.
- **Any heading below that — \`##\`, \`###\`, even deeper — becomes a topic, as
  long as list items appear directly underneath it** before the next
  heading. A heading with no list items under it (like a plain "Objective"
  or "Goal" sub-heading with just a sentence of prose) is skipped rather
  than turned into an empty topic.
- **Both checkbox and plain bullets become tasks:** \`- [ ] text\`, \`- [x] text\`
  (already done), or just \`- text\` (imported as not done). \`*\` and \`+\` work
  as bullet markers too.
- **Inline tags on a task line** are optional and stripped from the displayed
  title:
  - \`#priority:low\`, \`#priority:medium\`, or \`#priority:high\`
  - \`#due:YYYY-MM-DD\`
  - \`#repeat:daily\`, \`#repeat:weekdays\`, \`#repeat:weekly\`, or \`#repeat:monthly\`
- **Duplicate topic names are disambiguated automatically.** If your file
  reuses a heading like "Tech Stack" or "Features" under several different
  top-level sections, Waypoint tags each one with its nearest top-level
  heading (e.g. "Tech Stack (Project 1 - ...)") — but only when there's an
  actual collision, so a normal file's topic names are never touched.
- **Code blocks (\` \`\`\` \`), horizontal rules (\`---\`), and blockquotes (\`>\`)
  are skipped**, not warned about — they're formatting, not tasks.
- Anything else that doesn't match a rule — a stray tag, a malformed date, a
  paragraph of explanatory text with nothing to attach it to — doesn't fail
  the import. It's rolled up into a short warning count on the preview
  screen (e.g. "34 lines of explanatory text weren't recognized as tasks —
  skipped") rather than one line per occurrence, so a 500-line file doesn't
  bury you in 100 individual warnings.

## A worked example

\`\`\`markdown
# Modern C++
Getting comfortable with C++ as a daily language, not just for interviews.

## Smart Pointers
- [x] Read about unique_ptr
- [ ] Read about shared_ptr and weak_ptr #priority:medium
- [ ] Rewrite an old raw-pointer project using RAII #priority:high #due:2026-09-20

## Move Semantics
- [ ] Understand rvalue references
- [ ] Implement a move constructor and move assignment operator #priority:medium
\`\`\`

This creates one track ("Modern C++"), two topics ("Smart Pointers", "Move
Semantics"), and five tasks — one already marked done, two with priorities, one
with a due date.

### A messier, real-world example

This also works fine on something far less tidy — a multi-phase roadmap with
nested \`###\` sub-headings, plain (non-checkbox) bullets, ASCII workflow
diagrams in code blocks, and the same "Tech Stack" / "Features" heading
repeated under five different projects:

\`\`\`markdown
# Forward Deployed AI Engineer Roadmap

# Phase 1: AI Engineering Foundations

## Objective
Build a solid foundation in modern AI engineering.

### Python
- Syntax
- OOP
- Async Programming

### AI Fundamentals
- How LLMs work
- Tokens

# Project 1 - Production AI Customer Support

### Tech Stack
- FastAPI
- PostgreSQL

### Features
- Authentication
- Chat history

# Project 2 - AI Document Search

### Tech Stack
- LangChain
- Vector Database
\`\`\`

That imports as one track with topics "Python", "AI Fundamentals", "Tech
Stack (Project 1 - Production AI Customer Support)", "Features (Project 1 -
Production AI Customer Support)", "Tech Stack (Project 2 - AI Document
Search)", and so on — the "Objective" heading is skipped (no list items
directly under it), and the duplicate "Tech Stack" / "Features" names are
disambiguated automatically.

## Let an AI write it

You don't have to write this format by hand. In the import box, tap **Copy AI
prompt** and paste it into ChatGPT, Claude, Gemini or any other AI chat, with
your notes, a syllabus, or just the thing you want to learn.

The AI first asks you a few short questions, each one feeding a part of
Waypoint:

| It asks | It becomes |
| --- | --- |
| What's the goal, and what does done look like? | the track name and its **Headed to** sentence |
| What do you already know or have done? | tasks marked done, or left out |
| Is there a deadline? Dates leading up to it? | \`#due:\` dates, paced to your time |
| How much time do you have per day or week? | task size and spacing |
| Anything you want to do regularly? | \`#repeat:\` tasks |
| What matters most? | \`#priority:\` tags |

Answer what you like, or say "skip". It then writes the track in a code block
with a copy button. Copy it, or the whole reply, into the import box: Waypoint
takes the track out of the code block and ignores the chat around it. Several
goals come back as several blocks; import them one at a time.

The prompt carries today's date, so deadlines come out as real dates. Copy a
fresh one each time rather than reusing an old copy.

## Importing

From the dashboard, choose **+ Add track → Paste a plan**, paste the file,
and review the preview — it shows exactly what will be created, plus any
warnings — before you confirm.

Very long names are shortened to fit (a track name to 200 characters, a topic to
500, a task to 1,000), with a warning on the preview, so nothing fails to
import because a line ran on.
`,_=`---
title: Search, Review & Repeating Tasks
---
# Search, Review & Repeating Tasks

## TL;DR

- **Ctrl/⌘ + K** searches tracks, topics, tasks, notes and day lines at once.
- **Review** shows what slipped (with one-tap fixes), what's gone quiet and
  what's coming up.
- Tasks can repeat daily, on weekdays, weekly or monthly; ticking one off
  creates the next.
- **Review later…** on any task adds a "Review:" task due in 1, 3, 7, 21 or
  30 days, or on a date you pick.
- A missed deadline says **Deadline crossed · N days ago**.
- **Export** a track as Markdown, or download and restore a full **.json**
  backup from Settings.

Once a few tracks are filled in, the questions change from "what do I write
down?" to "where did I put that?" and "am I actually making progress?".

## Search

Press **Ctrl + K** (⌘ + K on a Mac) anywhere, or pick **Search** in the
sidebar. It looks through track names, topic titles, task titles, the text
of your notes and the lines you wrote when closing each day, all at once. Every word you type has to match, ignoring case and
accents, and open tasks rank above finished ones. Clicking a task or topic
opens its track with that topic already expanded.

## Review

**Review** is a check on what needs sorting out. Today links to it when tasks
have slipped. There are no streaks or activity grid on purpose: counting days
turns a quiet week into a debt. The trail on each track is the look back.

- **Done in the last 7 days**, next to the week before it, and focus time.
- **Slipped.** Overdue tasks that are still open. A pile of these is the
  quickest way to stop wanting to open a to-do list, so there are two ways to
  clear it in one move: **Move all to today**, or **Clear deadlines** (the
  tasks stay, they just stop being overdue).
- **Gone quiet.** Topics you started but haven't finished a task in for 14+
  days, and tracks with open work and nothing done in that time. Paused and
  archived tracks are left out on purpose.
- **Coming up** in the next 7 days, and everything **finished this week**.

History starts from when you tick things: tasks finished before this existed
count only from the moment they were stored as done.

## Repeating tasks

When adding or editing a task, the **Repeat** menu offers every day, every
weekday, every week or every month. Tick the task off and the next one is
created straight away, so a repeating task is always a single open item.

- The next date keeps the task's own rhythm (a weekly Monday task stays on
  Mondays), but never lands in the past, so finishing something a month late
  doesn't leave a pile of overdue copies.
- A task with no deadline repeats from today.
- Stop repeating by editing the open task and choosing "Doesn't repeat".
- A repeating mark (↻) shows next to it on Today and on the track page.

In Markdown, add \`#repeat:daily\`, \`#repeat:weekdays\`, \`#repeat:weekly\` or
\`#repeat:monthly\` next to \`#priority:\` and \`#due:\`.

## Reviewing a task later

When you want to go over something again, open the task (tap it on Today)
and choose **Review later…**, or pick **Review later…** in its ⋮ menu on the
track page. Choose **1, 3, 7, 21 or 30 days**, or a date of your own.

That adds a task called "Review: *the task's name*" to the same topic, due on
that day. The task you started from isn't changed. The review stays off
Today's suggestions until its day, then shows up like any other task due
today. Setting a review for the same task again moves the waiting one to the
new day instead of adding a second.

Waypoint never adds reviews by itself: you decide what's worth revisiting,
and when.

## Deadlines

A task's deadline reads as **Due today**, **Due tomorrow**, **Due in 3 days**
or a date. Once it has passed and the task is still open, it says **Deadline
crossed · 4 days ago** in red, on Today, on the track page, in the task's
details and in **Review your week**.

## Reordering and export

- **Drag a task** to change its order within its topic: on a phone, hold it
  for a moment until it lifts, then move it; in a browser, click and drag.
  A quick swipe still just scrolls. **Move up / Move down** in the task's ⋮
  menu do the same one step at a time, and **Move to…** puts it in another
  topic or track.
- **Export** on a track's page downloads it as Markdown, in exactly the format
  **Paste a plan** reads, so it round-trips.
- **Settings → Your data → Download .json** saves everything (tracks, topics,
  tasks, notes, ratings, the lines on your trails) as one backup file. Images and audio embedded in
  notes aren't part of it.
- **Settings → Your data → Choose file…** restores a backup. It always *adds*
  the contents as new tracks and notes; nothing you already have is changed or
  replaced, so restoring into an account that already holds the same data
  gives you a second copy. You see the counts and confirm first.
`,v=`---
title: Flashcards
---
# Flashcards

## TL;DR

- Write \`question :: answer\` on one line in any note and it becomes a card.
- Open **Flashcards** in the sidebar to review; rate each **Again / Hard / Good / Easy** (keys
  1–4).
- Edit the answer and the card keeps its schedule; edit the question and it's a
  new card; delete the line and the card goes.
- Sessions are capped at 20 cards, so nothing piles up.

Most flashcard apps make you stop and build cards, and that chore is what
people give up on. Waypoint has no card editor. You write in a note, and the
notes make the cards.

## Making a card

In any note, put a question and an answer on one line, separated by \` :: \`
(a space, two colons, a space):

\`\`\`
What does RAII stand for? :: Resource Acquisition Is Initialization
\`\`\`

Every line like that becomes a card when the note is saved. The note shows how
many cards it holds, and cards for a note are kept in step with it:

- Reword the **answer** and the card keeps its schedule.
- Reword the **question** and it's a new card, because the question is what
  identifies it.
- Delete the line, or the note, and the card goes too.
- Bold, links and other formatting are ignored; only the text counts.

Notes you wrote before cards existed are picked up the first time you open
**Flashcards** with none yet: use **Find cards in my notes**.

## Reviewing

Open **Flashcards** in the sidebar (the number is how many are due today). Show the
answer, then say how it went:

| Button | Key | What happens |
| --- | --- | --- |
| Again | 1 | Back to the start; it comes round again in this session |
| Hard | 2 | A slightly longer gap |
| Good | 3 | The normal step: 1 day, then 3, then growing by the card's ease |
| Easy | 4 | A bigger jump, and the card gets easier |

Space shows the answer, then counts as Good. Each button shows how long until
you'd see the card again.

## A session never buries you

A session holds at most 20 cards, oldest-due first. If more are due, the rest
simply wait; nothing is marked late and nothing piles up as a number to feel
bad about. When you finish you can take another 20 or stop.

Cards are included in the JSON backup and in restore.

On Supabase, cards need the latest \`supabase/setup.sql\` to have been run.
`,y="---\ntitle: Add a Task\n---\n# Add a Task\n\n## TL;DR\n\n- Press **C** anywhere (or tap **+ Add a task**) and type one line in plain\n  words.\n- When (`tomorrow`, `after 5 days`, `oct 20`), repeats (`every week`) and\n  priority (`!high`) are picked out of the text, and the date is worked out\n  for you.\n- \"Remind me to …\" works: `remind me to call the bank after 5 days` makes the\n  task **call the bank**, due 5 days from today.\n- Everything goes to your **To do** list, one plain list with no topics. To\n  add a task to a particular topic, use **+ Add task** on that track's page.\n\nCapturing a thought shouldn't mean choosing a track, a topic, a date and a\npriority first. Press **C** anywhere in the app (when you're not typing in a\nfield), or use **+ Add a task** at the top of the sidebar, and write one line.\n\n## What it understands\n\n| Write | You get |\n| --- | --- |\n| `tomorrow`, `today`, `day after tomorrow`, `next week`, `next month` | a deadline |\n| `friday`, `on friday`, `next monday` | the next time that day comes round |\n| `in 3 days`, `after 5 days`, `after a week`, `in three months`, `2 days later`, `5 days from now` | a deadline that far from today |\n| `oct 15`, `15 oct`, `2026-11-01` | that date (next year if it has passed) |\n| `every day`, `daily`, `every weekday`, `every week`, `every month` | a repeating task |\n| `every monday` | repeats weekly, starting next Monday |\n| `!high` `!medium` `!low` (or `!1` `!2` `!3`) | a priority |\n| `remind me to …`, `remind me about …`, `reminder: …` | left out of the task's name |\n\nNumbers can be digits or words up to twelve (\"three days\"), and \"a\" or \"an\"\nmeans one (\"after a week\"). The same `#priority:high`, `#due:2026-10-20` and\n`#repeat:weekly` tags the Markdown import reads work here too.\n\nBefore you press Enter, the box shows the task's name and what it understood,\nwith the worked-out date: *Due Fri, 23 Oct · in 5 days*. Whatever it\nunderstood is removed from the name; anything it doesn't understand stays, so\nnothing you typed is lost. For example:\n\n```\nremind me to submit the assignment after 3 days !high\n```\n\nbecomes **\"submit the assignment\"**, due three days from today, high\npriority.\n\n## The To do list\n\nEvery task added this way goes to your **To do** list, in the menu right under\n**Today**. It's one plain list of things to do: no topics, no trail, no\nroadmap. Tick tasks off, hold one to drag it into a new order, or add one\nstraight there with **+ Add task**. Its tasks show up on Today like anything\nelse when they're due. (It used to be called the Inbox, and is renamed\nautomatically.)\n\nThe box stays open after you add, so you can capture several in a row; **Esc**\ncloses it.\n\nTo put a task straight into a topic, open that track and use **+ Add task**\nunder the topic.\n\n## Sorting later\n\nOn a track's page, a task's ⋮ menu has **Move to…**. Pick a track and a topic\nand the task moves to the end of it; both topics' statuses are kept in step,\nand the task's note goes with it.\n",b=`---
title: Linking Notes
---
# Linking Notes

## TL;DR

- Write \`[[Name]]\` in a note to link to a note, task, topic or track of that
  name. Typing \`[[\` lists your notes' titles to pick from.
- **Ctrl/Cmd + click** follows the link; a link to nothing yet creates the
  note when you open it.
- Under each note: **Links** (what it points at) and **Linked from** (notes
  that point at it).

Write a name in double square brackets and it becomes a link:

\`\`\`
Pointers are easier once [[RAII]] clicks.
\`\`\`

As soon as you type \`[[\`, a list of your notes' titles appears under the
cursor, narrowing as you type. Pick one with a tap, or with ↑/↓ and Enter
(or Tab), and the link is finished for you, closing \`]]\` included. Esc hides
the list if you're linking to something that isn't a note, or to a note that
doesn't exist yet.

The text is highlighted in the note. **Ctrl/Cmd + click** it to open the
target. A plain click only places the cursor, so you can still edit the
link text.

## What a link can point at

The name is matched ignoring case and accents, in this order:

1. a **note** with that title (the most recently edited, if there are several)
2. a **task** with that title (an open one first), which opens that task's
   note, created on the spot if it has none yet
3. a **topic**, which opens its track with the topic expanded
4. a **track**

A link to nothing yet becomes a note of that name when you open it, so you can
write links first and fill the notes in later.

\`[[Title|shown text]]\` is accepted too; only the part before the bar is the
target.

## Under the note

Below a note, two lists appear once there's anything to show:

- **Links**: everything this note points at. Each is a tap-friendly link, with
  what it resolved to. Ones that point at nothing have a **Create note** button.
- **Linked from**: the other notes that mention this note's title in a
  \`[[link]]\`, newest first, each with the sentence around the link. This is
  how you find what builds on a note without having to remember it.

Rename a note and its backlinks follow its new title, because links are by
name: old \`[[links]]\` to the previous title stop matching until you update
them.
`,x=`---
title: The Focus Timer
---
# The Focus Timer

## TL;DR

- Start a timer from a task (**Focus on this**, or **▶ Focus** on Today) or with
  **Start a focus timer** in the sidebar.
- 25-minute focus, then you choose whether to start a 5-minute break. Change
  both in **Settings → Focus timer**.
- The end of a block is announced with a sound, a notification and a pop-up;
  in the Android app the notification arrives even with the app closed.
- Time is logged against the task and shown on **Review**.

A timer for working in blocks, tied to the task you're on.

## Starting one

- On **Today**, tap a task to open it, then tap **Focus on this**. Or press
  **▶ Focus** at the end of its row.
- On a track's page, use **Start focus timer** in a task's ⋮ menu.
- Or use **Start a focus timer** in the sidebar for a block that isn't about any
  particular task.

A small timer appears in the bottom-right corner of every page and keeps
running as you move around the app. The tab's title shows the clock too, so
you can see it from another tab. The task you're timing is marked
**Focusing** on Today.

## What happens

1. **Focus**: 25 minutes by default. **Pause** and **Resume** freeze it
   exactly; **Stop** ends it early.
2. When the block ends you're told **three ways at once**, so it can't be missed:
   a **sound** (two short tones), a **notification**, and a **pop-up** on
   screen. **Nothing starts by itself:** the pop-up asks whether to **start the
   5-minute break** or **skip the break**, and the break begins when you tap,
   not before, because you may have put the phone down and walked away.
3. **Break**: 5 minutes by default. **Skip** ends it. When it ends you get the
   same sound and notification, and the timer goes away.

The pop-up stays on screen until you answer it, and it is still there if you
come back to the app hours later (the break is only offered if the block ended
in the last half hour).

Both lengths are in **Settings → Focus timer**. They apply to the next block
you start, and are saved on that device.

## When the phone is on the desk

- **In the Android app**, the end of a block or a break arrives as a **system
  notification with a sound and vibration**, even if the app is closed or the
  screen is off. The first time you start a timer, Android asks to allow
  notifications; say yes. Tapping the notification opens the app on the "start
  the break" pop-up. If the app is open you get the app's own tones and the
  pop-up, and the notification is posted quietly so you don't hear two sounds.
- **In the browser or the installed web app**, you get the tones and the pop-up
  while the page is open, and if it's in the background a browser notification
  that stays until you click it. A closed browser tab can't be woken, so for a
  timer you'll walk away from, use the Android app.

If you've turned the sound off on your phone, Android keeps it off for the
notification too: check **Settings → Apps → Waypoint → Notifications → Focus
timer**.

The timer is based on clock time, not a counter, so a slow background tab
can't make it drift, and a block that ran out while the app was closed is
logged when you come back.

## What gets logged

A finished block logs its full length. Stopping early logs the whole minutes
you actually did (under a minute logs nothing). Time is logged against the
task, shown on its row next to the deadline, and on **Review**:

- **Focus, last 7 days** with the all-time total underneath, and
- **Where the time went**: the tasks the last week's blocks were spent on,
  with their tracks.

If you delete a task, the minutes you spent on it still count, just against
nothing.

Focus sessions are part of the JSON backup and restore. On Supabase, the
timer's log needs the latest \`supabase/setup.sql\` to have been run.
`,S=`---
title: On Your Phone
---
# On Your Phone

## TL;DR

- **Android:** install it from the website (recommended) or download the APK. **iPhone:** Safari → Share → Add to Home Screen.
- The app's screens update by themselves in the background; it switches to the
  new version when you next leave the app.
- **Swipe right** from the left side to open the sidebar, **swipe left** to
  close it. It works in the app and in this guide.
- Something wrong? **Settings → About → Update details**.

Waypoint works in any browser, installs like an app, and has an Android app.
This chapter covers getting it onto a phone, how it keeps itself up to date,
and the gestures.

## Installing

### Android: from the browser (recommended)

1. Open **waypoint.yudhvir.in** in Chrome.
2. Scroll to **Get the app** and tap **Install Waypoint**. If you don't see the
   button, open the **⋮ menu** and choose **Install app**.
3. Confirm. Waypoint appears on your home screen and opens full-screen.

There's no download, no security warning, and it updates itself.

### Android: the app file (APK)

1. On the same page, tap **Download the APK**, then open the file when it
   finishes.
2. If Android says it can't install from this source, tap **Settings** and
   allow installs from your browser, then go back.
3. If Play Protect warns about an unknown app, choose **Install anyway**.
4. Tap **Install**, then open Waypoint.

### iPhone and iPad

1. Open the site in **Safari** (not Chrome).
2. Tap **Share → Add to Home Screen → Add**.
3. Open it from your home screen.

### Computer

Open the site in any browser. In Chrome or Edge you can also use the install
icon in the address bar.

## Keeping it up to date

The website and the installed web app update themselves. The Android app has two
layers:

- **The app's screens and features** update quietly in the background. When you
  open the app online it checks and downloads what's new. It switches to the new
  version when you next leave the app (go to the home screen or another app), so
  it never changes under you while you're writing. To switch immediately, use
  **Settings → About → Check for updates**, then **Restart now to use it**.
- **The app itself** (rare) needs a new install file. When that happens a notice
  appears at the bottom of the screen and the download starts **by itself**,
  with a progress bar. When it finishes, Android shows its own
  "Do you want to update this app?" screen. Tap **Install**. That tap is
  Android's requirement for any app outside the Play Store; the app can't do it
  for you.

The first time, Android also asks you to allow Waypoint to install updates:
the notice has an **Open settings** button, you switch it on, and you come
back. You only do this once.

If you'd rather not update right now, tap **Not now**; it won't ask about that
version again. To check yourself, use **Settings → About → Check for
updates**. Your data stays through an update: it's the same app with the same
storage.

**Installed from Google Play?** Then Google Play updates the app itself, like
any other app, and Waypoint never downloads an install file. The screens and
features still update quietly in the background as above.

Before anything is installed the app checks the file against a fingerprint
published with the update and that it's really Waypoint, and Android refuses it
unless it was signed with the same key as the app you have.

## Gestures

On a phone the sidebar is a drawer, in the app and in this guide (where it
lists the chapters):

- **Swipe right** from the left side of the screen to open it. It follows your
  finger, and settles open or shut depending on how far you went or how fast you
  flicked.
- **Swipe left** anywhere to close it, like drawing a curtain.
- The ☰ button in the corner does the same.

The swipe is ignored where it would get in the way: in text fields, inside the
note editor, and on anything that scrolls sideways.
Android's own back gesture lives at the very edge of the screen, so you can
start the swipe a little further in.

## If something doesn't work

- **"Downloaded" but nothing changed:** open **Settings → About → Update
  details**. It shows which version is running, which one is waiting, and what
  has been downloaded, and says so when an update was downloaded but didn't take
  effect. **Restart now to use it** switches to the waiting version straight
  away and shows the reason if it can't.
- **No Install button on the site:** Chrome only offers it when the app isn't
  already installed. Use the ⋮ menu.
- **The update notice says it couldn't finish:** check your connection and tap
  **Try again**. A download that doesn't match its fingerprint is deleted
  rather than installed.
- **Google sign-in opens a browser and doesn't come back:** reinstall the app.
  Android verifies the link between the site and the app when it's installed.
`,C=`---
title: Setting Up Google Sign-In
---
# Setting Up Google Sign-In

## TL;DR

- **For whoever deploys Waypoint**, not for people using it. On
  waypoint.yudhvir.in this is already done; just tap **Sign in with Google**.
- **Sign in with Google** stores everything as one file in a "Waypoint" folder
  in the person's own Drive. Nothing else in their Drive is visible to the app.
- Setup: a Google Cloud OAuth client, the small \`google-token\` Edge Function
  that holds the client secret, and two build-time env vars.

Signing in with Google saves your tracks as one file in a "Waypoint" folder in
your own Google Drive. Like the Supabase option, this is one-time setup for
whoever is deploying the app — anyone who signs in afterward just clicks
"Sign in with Google", nothing more.

If you'd rather skip this, guest mode and Supabase both work without it.

## Why this needs more than an API key

Supabase's anon key is safe to put straight into the app because row-level
security does the actual protecting. Google's OAuth **client secret** is
different — anyone holding it could mint tokens as your app, so it can never
ship in the browser bundle. That's the one piece here that needs a server,
even though Waypoint otherwise has none: a small, stateless Supabase Edge
Function holds the secret and does nothing else. It stores no data of its
own — the refresh token it hands back is kept in the browser, in IndexedDB,
the same way a guest's tracks are.

## 1. Create a Google Cloud OAuth client

1. Go to [console.cloud.google.com](https://console.cloud.google.com) and
   create (or pick) a project.
2. **APIs & Services → Library** → enable the **Google Drive API**.
3. **APIs & Services → OAuth consent screen**:
   - User type: External (unless everyone using this is in your Google
     Workspace org).
   - Add the \`drive.file\` scope (per-file access only — the app can never
     see anything in your Drive besides what it creates itself) plus
     \`email\` and \`profile\`.
   - While in **Testing** status you can add up to 100 test users with no
     verification review needed — fine for personal or small-group use.
4. **APIs & Services → Credentials → Create Credentials → OAuth client ID**
   → **Web application**.
   - **Authorized JavaScript origins**: every origin the app runs on, e.g.
     \`https://waypoint.example.com\` and \`http://localhost:5173\`. Origin
     only — no path, no trailing slash.
   - **Authorized redirect URIs**: the full callback path on each of those
     same origins, e.g. \`https://waypoint.example.com/auth/google/callback\`
     and \`http://localhost:5173/auth/google/callback\`.
5. Copy the **Client ID** and **Client secret** from this credential.

## 2. Deploy the token-relay Edge Function

\`\`\`bash
supabase link --project-ref <your-project-ref>
supabase functions deploy google-token --no-verify-jwt
\`\`\`

\`--no-verify-jwt\` matters here: this function has to be callable before
anyone has a Supabase session (Drive sign-in doesn't require Supabase at
all), so Supabase's own gateway auth would only get in the way. The
function is safe to leave open — see its header comment in
\`supabase/functions/google-token/index.ts\` for why.

Set two secrets on whichever project you deployed it to (it doesn't need to
be the same project as your tracks/topics/tasks data — its only job is this
token exchange):

| Secret | Value |
| --- | --- |
| \`GOOGLE_CLIENT_ID\` | From step 1 |
| \`GOOGLE_CLIENT_SECRET\` | From step 1 — never put this one in the app itself |

## 3. Point the app at it

Set these as build-time env vars (e.g. in Vercel's project settings) —
both are safe to expose, same as \`VITE_SUPABASE_ANON_KEY\`:

\`\`\`bash
VITE_GOOGLE_CLIENT_ID=<the client id from step 1>
VITE_GOOGLE_TOKEN_RELAY_URL=https://<project-ref>.supabase.co/functions/v1/google-token
\`\`\`

Leave either unset and the "Sign in with Google" button shows as disabled
("Coming soon") instead of failing at sign-in time.

## What it looks like once it's live

Someone clicking "Sign in with Google" is sent to Google's consent screen,
then straight back into Waypoint signed in — no popups. Behind the scenes,
the app asked for offline access, so it holds onto a refresh token
(in IndexedDB, on that device) and quietly renews its access token through
the relay whenever the old one's about to expire, roughly once an hour.
There's nothing to re-authorize unless that refresh token itself is
revoked — from Google's side (myaccount.google.com → Security → Third-party
access) or by signing out in Waypoint.
`,w=`---
title: Your Day and the Trail
---
# Your Day and the Trail

## TL;DR

- Morning: **Today** asks you to pick up to three tasks, starting with what you
  left yesterday.
- Evening: **Close the day** asks for one line about what moved. That line is a
  **waypoint**.
- Each track's **Trail** shows where it's headed, the topics ahead, **you are
  here**, and every line you've written on it, back to the day you started.
- On your own Supabase project, re-run \`supabase/setup.sql\` once to get these.

Waypoint has a beginning and an end to each day. In the morning you pick a few
things to do. In the evening you write one line about what moved. Over weeks,
those lines become the trail on each of your tracks: where it's headed, where you
are, and how far you've come.

## Opening the day

**Today** is the first thing you see. Until you've picked anything, it asks you
to **pick up to three for today**:

- **Left from yesterday** lists yesterday's picks you didn't finish, first, so
  nothing quietly falls off. Tap **+ Today** to carry one over.
- **Suggested** is the ranked list that used to be called Focus Now: crossed
  deadlines first, then due soon, then priority, then the topic you're in the
  middle of. It shows six, and **at most two from each track**, so one busy
  track can't push your other goals off Today. A crossed deadline always gets
  through. The rest are under **More from your tracks**. Tap **+ Today** to
  pick one.

Three is the limit on what's still open, not on the day: finish one and you can
pick another. Tap a task to open it in place; **Not today** puts a pick back with the
rest. With three picked, everything else folds away under **Everything else**.

Picks follow you between your phone and your computer.

Every day line can be found again in **Search**, under **Day lines**, newest
first. Tapping one opens its track's trail. A line saved with **No track**
shows up there too.

Under your picks, one quiet line tells you when something else wants a moment:
cards to review, things waiting on your To do list, or tasks that have slipped. Those
used to be pages of their own in the sidebar; they're one tap away from here.

## Closing the day

At the bottom of Today, **Close the day** asks one question: *what did you
learn or get done today?* Write a line and press **Enter** (or **Save the
day**). It goes on the track most of today's finished picks came from; change
that with the **on** menu, or choose **No track**.

That line is a **waypoint**. Write another with **+ Another line** if the day
touched more than one track. Tomorrow, Today opens with yesterday's line at the
top, so each day starts where the last one ended.

## The trail

A track's page opens on its **Trail**, with **Tasks** one tap away (it
remembers which you used last). Read from the top:

1. **Headed to.** One sentence on why the track exists or where it ends. Tap it
   to change it. It's the track's description, so a Markdown import's
   description line fills it in.
2. **Ahead.** The next few topics you haven't reached, on a dashed line.
3. **You are here.** The topic you're in, how many tasks are left in it, and the
   topics already behind you. If you haven't written today's line for this
   track, you can write it right here.
4. **The trail itself.** Every line you've written on this track, newest first,
   one stop per day, back to the day you set out.

Tap any topic on the trail to jump to it in **Tasks**.

## Supabase: re-run the setup script

Picks and waypoints need two things added to your database. Re-run
\`supabase/setup.sql\` in the SQL Editor; it's safe to re-run and only adds what's
missing. Until then, Today shows the ranked list as before and says what to do.
Guest mode and Google Drive need nothing.
`,T=`---
title: Words and Writing
---
# Words and Writing

## TL;DR

- Select a word or a short phrase in a note, then tap **Define** on the
  toolbar that appears. A card shows its meanings, an example and, for most
  single words, the pronunciation with a ▶ button.
- **Check writing**, above every note, finds spelling, grammar and style
  problems and fixes each one with a tap.
- Pressing Enter starts the next line plain: a colour, highlight or size
  stays on the text you gave it.
- English only. Both need an internet connection, and only send text when
  you press the button.

## Looking up a word

Select some text in any note. The formatting toolbar (bold, size, colours)
appears above it, and when the selection is a word or a phrase of up to six
words, it ends with **Define**. Tap it and the toolbar grows a card with:

- the word and, if known, how it's pronounced, with ▶ to play it
- its meanings, grouped by part of speech (noun, verb, adjective…), up to
  three each, with an example sentence where there is one
- where the definition came from

The note isn't changed. Select something else or tap outside to close it.
Commas, brackets and quotes around a selection are ignored, so selecting
"ubiquitous," finds *ubiquitous*.

## Phrases

Phrases and idioms work too: select *in lieu of*, *by and large* or
*take for granted* and Define finds them. Single words are looked up in the
Free Dictionary first, which has the pronunciations; phrases, and words it
doesn't know, come from Wiktionary.

If neither has it, the card says so. That usually means the selection is a
name, a typo, or a phrase that isn't a fixed expression, so try fewer words.

## Checking your writing

**Check writing** sits next to **Image** and **Audio** above the note. Press
it and a list opens of what could be better, each marked as one of:

- **spelling**: a word that isn't spelled right
- **grammar**: "he go" for *he goes*, "can be get" for *can be got*
- **style**: wordy, repeated or weak phrasing, the "make this sentence
  better" kind of suggestion

Each has the suggested fixes as buttons: tap one and the note changes. Tap
the problem itself to jump to it in the note, or **Ignore** to drop it from
the list. The list keeps up as you edit, so fixing something by hand removes
it too.

It checks British English, so *colour* and *organise* aren't flagged. It
suggests fixes to words and phrases; it doesn't rewrite whole sentences or
paragraphs for you.

The checker is [LanguageTool](https://languagetool.org)'s free service. The
note's text is sent to it only when you press the button, and a note can be
up to about 20,000 characters. If you check many times within a minute, it
asks you to wait a moment.

## New lines start plain

Colour a word, highlight it or make it bigger, then press Enter at the end of
it: the next line starts as plain text. The formatting stays on what you
gave it. To carry on in the same colour, pick it again on the new line.

## Turning a word into a flashcard

To remember a word, write it as a flashcard line in the note:

\`\`\`
ubiquitous :: present everywhere
\`\`\`

The **Flashcards** chapter explains how those are reviewed.
`,E=r(),D=[{slug:`welcome`,raw:m},{slug:`your-day-and-the-trail`,raw:w},{slug:`connecting-your-supabase-project`,raw:h},{slug:`the-markdown-import-format`,raw:g},{slug:`search-review-and-repeating-tasks`,raw:_},{slug:`flashcards`,raw:v},{slug:`quick-add`,raw:y},{slug:`linking-notes`,raw:b},{slug:`words-and-writing`,raw:T},{slug:`focus-timer`,raw:x},{slug:`on-your-phone`,raw:S},{slug:`google-drive-setup`,raw:C}].map(({slug:e,raw:t})=>{let{title:n,body:r}=u(t);return{slug:e,title:n,html:p(l.parse(r,{async:!1}))}});function O(){return(0,E.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,children:[(0,E.jsx)(`rect`,{x:`3`,y:`4`,width:`18`,height:`16`,rx:`2`}),(0,E.jsx)(`line`,{x1:`9`,y1:`4`,x2:`9`,y2:`20`})]})}function k(){let{hash:t}=e(),{backend:n}=a(),r=n?`/`:`/login`,[i,o]=(0,d.useState)(()=>window.innerWidth>=768),l=(0,d.useRef)(null),u=(0,d.useRef)(null);s({open:i,setOpen:o,drawer:l,overlay:u});let f=t?t.slice(1):D[0].slug,p=D.find(e=>e.slug===f)??D[0];return(0,d.useEffect)(()=>{window.scrollTo({top:0})},[f]),(0,E.jsxs)(`div`,{className:`mx-auto flex min-h-screen max-w-5xl`,children:[(0,E.jsx)(`div`,{ref:u,className:`fixed inset-0 z-40 bg-black/50 transition-opacity duration-200 md:hidden ${i?`opacity-100`:`pointer-events-none opacity-0`}`,onClick:()=>o(!1),"aria-hidden":`true`}),(0,E.jsx)(`aside`,{ref:l,className:`fixed inset-y-0 left-0 z-50 w-72 overflow-hidden border-r border-border bg-card transition-transform duration-200 md:static md:z-auto md:translate-x-0 md:transition-[width] ${i?`translate-x-0 md:w-64`:`-translate-x-full md:w-0 md:translate-x-0 md:border-r-0`}`,children:(0,E.jsxs)(`div`,{className:`w-72 px-5 py-8 md:w-64`,children:[(0,E.jsxs)(`div`,{className:`flex items-center justify-between`,children:[(0,E.jsx)(`p`,{className:`text-xs font-semibold uppercase tracking-wider text-muted-foreground`,children:`Guide`}),(0,E.jsx)(`button`,{type:`button`,onClick:()=>o(!1),"aria-label":`Close chapter list`,className:`rounded-md p-1 text-muted-foreground hover:text-foreground md:hidden`,children:`✕`})]}),(0,E.jsx)(`nav`,{className:`mt-4 flex flex-col gap-0.5 text-sm`,children:D.map(e=>(0,E.jsx)(c,{to:`/guide#${e.slug}`,onClick:()=>o(window.innerWidth>=768),className:`rounded-md px-2 py-1.5 transition-colors ${e.slug===f?`bg-accent font-medium text-accent-foreground`:`text-muted-foreground hover:bg-accent hover:text-accent-foreground`}`,children:e.title},e.slug))})]})}),(0,E.jsxs)(`div`,{className:`min-w-0 flex-1 px-4 py-8 sm:px-8`,children:[(0,E.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,E.jsx)(`button`,{type:`button`,onClick:()=>o(e=>!e),"aria-label":i?`Hide chapter list`:`Show chapter list`,"aria-pressed":i,className:`flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-border text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground`,children:(0,E.jsx)(O,{})}),(0,E.jsx)(c,{to:r,className:`text-sm text-muted-foreground hover:underline`,children:`← Back to Waypoint`})]}),(0,E.jsx)(`div`,{className:`prose prose-sm mt-8 max-w-none dark:prose-invert`,dangerouslySetInnerHTML:{__html:p.html}},p.slug)]})]})}var A=[{slug:`welcome`,raw:m},{slug:`your-day-and-the-trail`,raw:w},{slug:`connecting-your-supabase-project`,raw:h},{slug:`the-markdown-import-format`,raw:g},{slug:`search-review-and-repeating-tasks`,raw:_},{slug:`flashcards`,raw:v},{slug:`quick-add`,raw:y},{slug:`linking-notes`,raw:b},{slug:`words-and-writing`,raw:T},{slug:`focus-timer`,raw:x},{slug:`on-your-phone`,raw:S},{slug:`google-drive-setup`,raw:C}].map(({slug:e,raw:t})=>{let{title:n,body:r}=u(t),i=p(l.parse(r,{async:!1})),a=/<p>([\s\S]*?)<\/p>/.exec(i)?.[1]??``;return{slug:e,title:n,html:i,summary:new DOMParser().parseFromString(a,`text/html`).body.textContent?.trim()??``}});function j(){return(0,E.jsx)(`div`,{"aria-hidden":`true`,className:`relative hidden h-72 items-center justify-center rounded-2xl bg-[#3a63c8] shadow-lg md:flex`,children:(0,E.jsxs)(`svg`,{viewBox:`0 0 400 240`,className:`h-full w-full p-6`,fill:`none`,stroke:`white`,strokeOpacity:`0.85`,strokeWidth:`1.5`,children:[(0,E.jsx)(`path`,{d:`M70 40h120v160H70z`}),(0,E.jsx)(`path`,{d:`M70 70h120M70 100h120M70 130h80`,strokeOpacity:`0.5`}),(0,E.jsx)(`path`,{d:`M210 60h110v130H210z`}),(0,E.jsx)(`path`,{d:`M225 85h80M225 110h80M225 135h50`,strokeOpacity:`0.5`}),(0,E.jsx)(`circle`,{cx:`330`,cy:`50`,r:`22`,fill:`white`,fillOpacity:`0.9`,stroke:`none`}),(0,E.jsx)(`path`,{d:`M190 120h20`,strokeDasharray:`3 4`}),(0,E.jsx)(`path`,{d:`m60 215 20-20 20 20`})]})})}function M(){let{ready:e,backend:t}=a();return e?t?(0,E.jsx)(k,{}):(0,E.jsx)(N,{}):null}function N(){let{hash:t}=e(),n=t?t.slice(1):``,r=A.find(e=>e.slug===n);return(0,d.useEffect)(()=>{window.scrollTo({top:0}),document.title=r?`${r.title} — Waypoint Guide`:`Guide — Waypoint`},[r]),(0,E.jsxs)(`div`,{className:`min-h-screen bg-background`,children:[(0,E.jsx)(o,{}),(0,E.jsx)(`section`,{className:`bg-[#f4f4f5] dark:bg-[#0b0b0b]`,children:(0,E.jsxs)(`div`,{className:`mx-auto grid max-w-6xl items-center gap-8 px-6 py-12 md:grid-cols-2 md:py-14`,children:[(0,E.jsxs)(`div`,{children:[(0,E.jsx)(`h1`,{className:`text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl`,children:r?r.title:`Guide`}),(0,E.jsx)(`p`,{className:`mt-5 text-lg`,children:r?`Waypoint guide`:`Learn how to set up and get the most out of Waypoint`})]}),(0,E.jsx)(j,{})]})}),(0,E.jsx)(`main`,{className:`mx-auto max-w-6xl px-6 py-14`,children:r?(0,E.jsxs)(`div`,{className:`grid gap-10 md:grid-cols-[14rem_1fr]`,children:[(0,E.jsxs)(`nav`,{className:`flex flex-col gap-1 text-sm md:sticky md:top-6 md:self-start`,children:[(0,E.jsx)(c,{to:`/guide`,className:`mb-2 font-semibold text-primary hover:underline`,children:`← All chapters`}),A.map(e=>(0,E.jsx)(c,{to:`/guide#${e.slug}`,className:`rounded-md px-2 py-1.5 ${e.slug===r.slug?`bg-accent font-medium text-accent-foreground`:`text-muted-foreground hover:text-foreground`}`,children:e.title},e.slug))]}),(0,E.jsx)(`article`,{className:`prose max-w-3xl dark:prose-invert prose-a:text-primary`,dangerouslySetInnerHTML:{__html:r.html}},r.slug)]}):(0,E.jsxs)(E.Fragment,{children:[(0,E.jsx)(`h2`,{className:`text-4xl font-extrabold tracking-tight`,children:`Chapters`}),(0,E.jsx)(`p`,{className:`mt-6 max-w-2xl text-xl leading-relaxed`,children:`Everything you need, from connecting your storage to importing existing notes. Each chapter stands on its own, so start wherever makes sense.`}),(0,E.jsx)(`div`,{className:`mt-10 grid gap-x-16 gap-y-10 md:grid-cols-2`,children:A.map(e=>(0,E.jsxs)(`div`,{children:[(0,E.jsx)(c,{to:`/guide#${e.slug}`,className:`text-base font-bold text-primary hover:underline`,children:e.title}),(0,E.jsx)(`p`,{className:`mt-3 text-sm leading-relaxed`,children:e.summary})]},e.slug))})]})}),(0,E.jsx)(i,{})]})}export{M as Guide};