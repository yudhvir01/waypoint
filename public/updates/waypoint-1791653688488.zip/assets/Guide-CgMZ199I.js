import{T as e,d as t,m as n,u as r,v as i,w as a,x as o,y as s}from"./index-Cmz2hmiW.js";import{n as c,t as l}from"./frontMatter-Ct_F--A0.js";var u=e(a(),1),d=`---
title: Welcome
---
# Welcome

Waypoint is one dashboard for everything you're learning and building — instead of
digging through a dozen notes to remember what you're supposed to be doing today,
you get one ranked list: what's overdue, what's urgent, and what's next, across
every track you're working on.

## How it's different

Most note apps (Notion, Obsidian) give you a blank page and a thousand templates.
Waypoint gives you three things and nothing else:

- **Tracks** — a subject you're working on (C++, Robotics, Interview Prep, a side
  project — whatever you're actually juggling).
- **Topics** — a unit inside a track (e.g. "Pointers", "ROS basics"), with a
  status: not started, in progress, or done.
- **Tasks** — the actual next actions inside a topic, each with an optional
  priority and due date.

Everything rolls up into one **Focus Now** list on the dashboard: the tasks that
most need your attention right now, blended from what's overdue, what's due soon,
and what you've manually flagged as high priority.

**Tap any task** in Focus Now and it opens right there, without taking you to its
track: the whole title (which you can edit, so a long one is never a problem),
its priority, deadline and repeat, its notes to write in, and a **Focus on
this** button that starts the timer on it.

## Your data is yours

Waypoint doesn't have a database of its own. The login screen offers three ways to
use it:

- **Guest** — no account, nothing to set up. Your notes are saved only in this
  browser's local storage, which is easy to lose (clearing site data, a private
  window, a different device all mean starting over).
- **Supabase** — you connect a project *you* create and control; your notes live
  there, not on anyone else's server, and follow you to any device you sign into.
- **Google** — saves into a "Waypoint" folder in your own Drive. Only that folder is ever touched, never the rest of your Drive.

## More than a task list

Around those three things, Waypoint is also a notebook and a place to look back:

- **Notes** that sit inside a task or stand alone, with images, audio, link
  previews and \`[[links]]\` between notes, tasks, topics and tracks.
- **Flashcards** made by writing \`question :: answer\` in a note, reviewed in
  short daily sessions.
- **Search** across everything, **Review** (streaks, an activity grid, what
  slipped), **repeating tasks**, **spaced revisit** and a **focus timer**.
- **Quick add**: press **C**, write a line, and the date, repeat and priority are
  picked out of it.
- **Export and backup**, so nothing is stuck inside the app.

Each of those has its own chapter in this guide.

## Get it on your phone

Waypoint installs like an app on Android and iPhone, with an Android app that
updates itself. The chapter **On Your Phone** has the steps.

Guest mode is there to try Waypoint out. The next chapter walks through the
Supabase setup for anyone who wants their notes to actually last — and if you've
already been using guest mode, Settings has a one-click "Move to Supabase" that
imports everything you've added.
`,f=`---
title: Connecting Your Supabase Project
---
# Connecting Your Supabase Project

Waypoint's login screen offers three ways in: try it as a guest with no setup (your
data stays only in that browser), sign in with Google (your data lives in a
Waypoint folder in your own Drive), or connect your own
[Supabase](https://supabase.com) project — a real Postgres database, under your
account, that only your Waypoint app talks to. Google and Supabase both follow you
across devices; guest mode doesn't.

This chapter covers that last option. It takes about five minutes, once. Already
using guest mode? Settings has a "Move to Supabase" button that walks you through
this same setup and then imports everything you've already added.

## 1. Create a Supabase project

1. Go to [supabase.com](https://supabase.com) and sign up (free, no card required
   for the free tier).
2. Click **New project**.
3. Give it a name (e.g. "waypoint-tracker"), set a database password (save it
   somewhere — you won't need it for the app, but it's good practice to keep it),
   and pick the region closest to you.
4. Wait for the project to finish provisioning — usually under two minutes.

## 2. Run the setup script

Waypoint ships with one SQL file, \`supabase/setup.sql\`, that creates every table it
needs and locks them down so only you can read or write your own data.

1. In your new Supabase project, open **SQL Editor** in the left sidebar.
2. Click **New query**.
3. Open \`supabase/setup.sql\` from the Waypoint repository, copy the whole file, and
   paste it into the query editor.
4. Click **Run**.

You should see a success message. If you ever want to double-check it worked, open
**Table Editor** — you should see \`tracks\`, \`topics\`, \`tasks\`, and \`topic_counts\`
listed. It also creates a public \`attachments\` bucket (for images/audio you attach
to a note), which shows up under **Storage**, not Table Editor.

The script is safe to run more than once, so if you update Waypoint later, just
paste the newest version of the file in and run it again. It brings an existing
database up to date — adding columns, indexes and helper functions — without
touching the tracks and tasks you've already written.

**Optional — link previews on paste:** pasting a bare URL into a note only turns
into a preview card (title, description, image) if \`supabase/functions/link-preview\`
is deployed. From the repository, with the [Supabase CLI](https://supabase.com/docs/guides/cli)
linked to your project: \`supabase functions deploy link-preview --no-verify-jwt\`.
It's stateless and needs no secrets. Skipping this just leaves pasted links as
plain links — nothing else in the app depends on it.

This function isn't tied to whoever's connected project it lives on — the app
calls it the same way regardless of which backend someone's using. If you're
running your own deployment of Waypoint (not just using it against your own
data), deploy it to the project behind \`VITE_SUPABASE_URL\` (or set
\`VITE_LINK_PREVIEW_URL\` to point at wherever you deployed it) so link previews
work for every visitor, including guest and Google Drive users, who have no
Supabase project of their own to deploy it to. Deploying it only to *your own*
bring-your-own project makes it work for you, in Supabase mode, and no one
else.

## 3. Get your project ID and anon key

1. In Supabase, open **Project Settings → General** and copy the **Project ID**
   (also called the project ref — a string like \`qmhmosjgokreigmsaklx\`). It's also
   the subdomain of your project URL: \`https://<project-id>.supabase.co\`.
2. Open **Project Settings → API Keys** and copy the **anon / public** key (a long
   string starting with \`eyJ...\`, or \`sb_publishable_...\` on newer projects). This
   key is safe to use in a browser app — it only grants the access your row-level
   security policies allow, which is: you can only ever see your own rows.

Do **not** use the \`service_role\` / secret key here — that key bypasses all
security rules and should never be pasted into a client app.

## 4. Connect Waypoint

1. Open Waypoint. On first run it'll show **Connect your Supabase project**.
2. Paste in the Project ID and anon key from step 3. Waypoint builds the full
   project URL for you.
3. Click **Connect**. Waypoint checks that it can reach your project and that the
   setup script ran successfully before saving anything.
4. You'll land on the sign-up screen — create an account (this is your own
   account, inside your own Supabase project, separate from your Supabase login).

That's it. Your Project ID and anon key are saved only in your browser — Waypoint
never sends them anywhere else, and every device you use (phone, laptop) just
needs the same project ID and key to see the same data.

## Using more than one device

To use Waypoint on your phone as well as your laptop, open Waypoint on the phone and go
through the same **Connect your Supabase project** step with the same project ID
and anon key. Then log in with the same account. Both devices now read and write
the same Supabase project, so changes sync automatically.
`,p=`---
title: The Markdown Import Format
---
# The Markdown Import Format

Instead of clicking through the UI to build out a whole track by hand, you can
write it as a plain Markdown file and import it in one go — useful if you're
bringing in an existing Obsidian note, or you just think better in a text editor.

The importer is intentionally simple, but it's built to survive a real,
messy roadmap file — nested headings, plain bullet lists, code blocks, the
works — not just a clean toy example.

## The basic shape

\`\`\`markdown
# Track Name
Optional free-text description line(s) before the first heading with list
items under it become the track description.

## Topic Title
- [ ] Task text #priority:high #due:2026-09-10
- [x] Completed task (already done)
- Task with no checkbox also works, and starts as not done
\`\`\`

## The rules

- **The first \`#\` heading is the track name.** Required, and it must come
  first.
- **Any heading below that — \`##\`, \`###\`, even deeper — becomes a topic, as
  long as list items appear directly underneath it** before the next
  heading. A heading with no list items under it (like a plain "Objective"
  or "Goal" sub-heading with just a sentence of prose) is skipped rather
  than turned into an empty topic.
- **Both checkbox and plain bullets become tasks:** \`- [ ] text\`, \`- [x] text\`
  (already done), or just \`- text\` (imported as not done). \`*\` and \`+\` work
  as bullet markers too.
- **Inline tags on a task line** are optional and stripped from the displayed
  title:
  - \`#priority:low\`, \`#priority:medium\`, or \`#priority:high\`
  - \`#due:YYYY-MM-DD\`
  - \`#repeat:daily\`, \`#repeat:weekdays\`, \`#repeat:weekly\`, or \`#repeat:monthly\`
- **Duplicate topic names are disambiguated automatically.** If your file
  reuses a heading like "Tech Stack" or "Features" under several different
  top-level sections, Waypoint tags each one with its nearest top-level
  heading (e.g. "Tech Stack (Project 1 - ...)") — but only when there's an
  actual collision, so a normal file's topic names are never touched.
- **Code blocks (\` \`\`\` \`), horizontal rules (\`---\`), and blockquotes (\`>\`)
  are skipped**, not warned about — they're formatting, not tasks.
- Anything else that doesn't match a rule — a stray tag, a malformed date, a
  paragraph of explanatory text with nothing to attach it to — doesn't fail
  the import. It's rolled up into a short warning count on the preview
  screen (e.g. "34 lines of explanatory text weren't recognized as tasks —
  skipped") rather than one line per occurrence, so a 500-line file doesn't
  bury you in 100 individual warnings.

## A worked example

\`\`\`markdown
# Modern C++
Getting comfortable with C++ as a daily language, not just for interviews.

## Smart Pointers
- [x] Read about unique_ptr
- [ ] Read about shared_ptr and weak_ptr #priority:medium
- [ ] Rewrite an old raw-pointer project using RAII #priority:high #due:2026-09-20

## Move Semantics
- [ ] Understand rvalue references
- [ ] Implement a move constructor and move assignment operator #priority:medium
\`\`\`

This creates one track ("Modern C++"), two topics ("Smart Pointers", "Move
Semantics"), and five tasks — one already marked done, two with priorities, one
with a due date.

### A messier, real-world example

This also works fine on something far less tidy — a multi-phase roadmap with
nested \`###\` sub-headings, plain (non-checkbox) bullets, ASCII workflow
diagrams in code blocks, and the same "Tech Stack" / "Features" heading
repeated under five different projects:

\`\`\`markdown
# Forward Deployed AI Engineer Roadmap

# Phase 1: AI Engineering Foundations

## Objective
Build a solid foundation in modern AI engineering.

### Python
- Syntax
- OOP
- Async Programming

### AI Fundamentals
- How LLMs work
- Tokens

# Project 1 - Production AI Customer Support

### Tech Stack
- FastAPI
- PostgreSQL

### Features
- Authentication
- Chat history

# Project 2 - AI Document Search

### Tech Stack
- LangChain
- Vector Database
\`\`\`

That imports as one track with topics "Python", "AI Fundamentals", "Tech
Stack (Project 1 - Production AI Customer Support)", "Features (Project 1 -
Production AI Customer Support)", "Tech Stack (Project 2 - AI Document
Search)", and so on — the "Objective" heading is skipped (no list items
directly under it), and the duplicate "Tech Stack" / "Features" names are
disambiguated automatically.

## Importing

From the dashboard, choose **+ Add track → Import Markdown**, paste the file,
and review the preview — it shows exactly what will be created, plus any
warnings — before you confirm.
`,m=`---
title: Search, Review & Repeating Tasks
---
# Search, Review & Repeating Tasks

Once a few tracks are filled in, the questions change from "what do I write
down?" to "where did I put that?" and "am I actually making progress?".

## Search

Press **Ctrl + K** (⌘ + K on a Mac) anywhere, or pick **Search** in the
sidebar. It looks through track names, topic titles, task titles and the text
of your notes at once. Every word you type has to match, ignoring case and
accents, and open tasks rank above finished ones. Clicking a task or topic
opens its track with that topic already expanded.

## Review

**Review** in the sidebar is a look back at the last few weeks:

- **Done in the last 7 days**, next to the week before it.
- **Streaks.** Days you finished at least one task. One rest day between two
  active days doesn't break it, and it's still alive until two days have gone
  by with nothing. Next to it, **active days in the last 30** gives a view
  that a single bad week can't wreck.
- **Activity.** A 26-week grid, one square per day, darker for busier days.
- **Slipped.** Overdue tasks that are still open. A pile of these is the
  quickest way to stop wanting to open a to-do list, so there are two ways to
  clear it in one move: **Move all to today**, or **Clear deadlines** (the
  tasks stay, they just stop being overdue).
- **Shaky** and **Finished but unrated.** See "Rating a topic" below.
- **Gone quiet.** Topics you started but haven't finished a task in for 14+
  days, and tracks with open work and nothing done in that time. Paused and
  archived tracks are left out on purpose.
- **Coming up** in the next 7 days, and everything **finished this week**.

History starts from when you tick things: tasks finished before this existed
count only from the moment they were stored as done.

## Repeating tasks

When adding or editing a task, the **Repeat** menu offers every day, every
weekday, every week or every month. Tick the task off and the next one is
created straight away, so a repeating task is always a single open item.

- The next date keeps the task's own rhythm (a weekly Monday task stays on
  Mondays), but never lands in the past, so finishing something a month late
  doesn't leave a pile of overdue copies.
- A task with no deadline repeats from today.
- Stop repeating by editing the open task and choosing "Doesn't repeat".
- A repeating mark (↻) shows next to it in Focus Now and on the track page.

In Markdown, add \`#repeat:daily\`, \`#repeat:weekdays\`, \`#repeat:weekly\` or
\`#repeat:monthly\` next to \`#priority:\` and \`#due:\`.

## Rating a topic

Ticking everything off says you did it, not that it stuck. Each topic has a
small **Rate** chip: click it to cycle **Shaky → Okay → Solid → unrated**. It's
your own call, not a quiz.

- A topic rated **shaky** comes back sooner (reviews at 1, 3 and 7 days);
  **solid** later (7 and 30 days). Unrated uses the middle schedule.
- Rating a finished topic shaky books its reviews straight away.
- **Review** lists your shaky topics, and finished ones you haven't rated.

## Spaced revisit

Finishing every task in a topic adds review tasks to that track, due 3, 7 and
21 days later by default, e.g. "Review: Pointers (day 7)". They live in a
**Reviews** topic that's created for you. At most 12 reviews stay open on a
track; past that, new ones wait until you've cleared some, so finishing a big
roadmap doesn't bury you. Switch it off in **Settings → Learning** (the choice
is saved on the device you set it on).

## Reordering and export

- **Move up / Move down** in a task's ⋮ menu changes its order within the topic.
- **Export** on a track's page downloads it as Markdown, in exactly the format
  **Import Markdown** reads, so it round-trips.
- **Settings → Your data → Download .json** saves everything (tracks, topics,
  tasks, notes, ratings) as one backup file. Images and audio embedded in
  notes aren't part of it.
- **Settings → Your data → Choose file…** restores a backup. It always *adds*
  the contents as new tracks and notes; nothing you already have is changed or
  replaced, so restoring into an account that already holds the same data
  gives you a second copy. You see the counts and confirm first.
`,h=`---
title: Flashcards
---
# Flashcards

Most flashcard apps make you stop and build cards, and that chore is what
people give up on. Waypoint has no card editor. You write in a note, and the
notes make the cards.

## Making a card

In any note, put a question and an answer on one line, separated by \` :: \`
(a space, two colons, a space):

\`\`\`
What does RAII stand for? :: Resource Acquisition Is Initialization
\`\`\`

Every line like that becomes a card when the note is saved. The note shows how
many cards it holds, and cards for a note are kept in step with it:

- Reword the **answer** and the card keeps its schedule.
- Reword the **question** and it's a new card, because the question is what
  identifies it.
- Delete the line, or the note, and the card goes too.
- Bold, links and other formatting are ignored; only the text counts.

Notes you wrote before cards existed are picked up the first time you open
**Cards** with none yet: use **Find cards in my notes**.

## Reviewing

Open **Cards** in the sidebar (the number is how many are due today). Show the
answer, then say how it went:

| Button | Key | What happens |
| --- | --- | --- |
| Again | 1 | Back to the start; it comes round again in this session |
| Hard | 2 | A slightly longer gap |
| Good | 3 | The normal step: 1 day, then 3, then growing by the card's ease |
| Easy | 4 | A bigger jump, and the card gets easier |

Space shows the answer, then counts as Good. Each button shows how long until
you'd see the card again.

## A session never buries you

A session holds at most 20 cards, oldest-due first. If more are due, the rest
simply wait; nothing is marked late and nothing piles up as a number to feel
bad about. When you finish you can take another 20 or stop.

Cards are included in the JSON backup and in restore.

On Supabase, cards need the latest \`supabase/setup.sql\` to have been run.
`,g="---\ntitle: Quick Add\n---\n# Quick Add\n\nCapturing a thought shouldn't mean choosing a track, a topic, a date and a\npriority first. Press **C** anywhere in the app (when you're not typing in a\nfield), or use **+ Quick add** at the top of the sidebar, and write one line.\n\n## What it understands\n\n| Write | You get |\n| --- | --- |\n| `tomorrow`, `today`, `next week`, `next month` | a deadline |\n| `friday`, `on friday`, `next monday` | the next time that day comes round |\n| `in 3 days`, `in 2 weeks` | a deadline that far ahead |\n| `oct 15`, `15 oct`, `2026-11-01` | that date (next year if it has passed) |\n| `every day`, `daily`, `every weekday`, `every week`, `every month` | a repeating task |\n| `every monday` | repeats weekly, starting next Monday |\n| `!high` `!medium` `!low` (or `!1` `!2` `!3`) | a priority |\n| `#cpp` | put it in the track whose name starts with (or contains) \"cpp\" |\n\nThe same `#priority:high`, `#due:2026-10-20` and `#repeat:weekly` tags the\nMarkdown import reads work here too.\n\nWhatever it understood is shown as chips under the box before you press\nEnter, and is removed from the title. Anything it doesn't understand stays in\nthe title, so nothing you typed is lost. For example:\n\n```\nsubmit assignment friday !high #uni\n```\n\nbecomes **\"submit assignment\"**, due Friday, high priority, in your *Uni*\ntrack.\n\n## The Inbox\n\nWith no `#track`, or one that matches nothing, the task goes to an **Inbox**\ntrack that's created the first time you need it. It shows up in Focus Now like\nanything else. The box stays open after you add, so you can capture several in\na row; **Esc** closes it.\n\n## Sorting later\n\nOn a track's page, a task's ⋮ menu has **Move to…**. Pick a track and a topic\nand the task moves to the end of it; both topics' statuses are kept in step,\nand the task's note goes with it.\n",_=`---
title: Linking Notes
---
# Linking Notes

Write a name in double square brackets and it becomes a link:

\`\`\`
Pointers are easier once [[RAII]] clicks.
\`\`\`

The text is highlighted in the note. **Ctrl/Cmd + click** it to open the
target. A plain click only places the cursor, so you can still edit the
link text.

## What a link can point at

The name is matched ignoring case and accents, in this order:

1. a **note** with that title (the most recently edited, if there are several)
2. a **task** with that title (an open one first), which opens that task's
   note, created on the spot if it has none yet
3. a **topic**, which opens its track with the topic expanded
4. a **track**

A link to nothing yet becomes a note of that name when you open it, so you can
write links first and fill the notes in later.

\`[[Title|shown text]]\` is accepted too; only the part before the bar is the
target.

## Under the note

Below a note, two lists appear once there's anything to show:

- **Links**: everything this note points at. Each is a tap-friendly link, with
  what it resolved to. Ones that point at nothing have a **Create note** button.
- **Linked from**: the other notes that mention this note's title in a
  \`[[link]]\`, newest first, each with the sentence around the link. This is
  how you find what builds on a note without having to remember it.

Rename a note and its backlinks follow its new title, because links are by
name: old \`[[links]]\` to the previous title stop matching until you update
them.
`,v=`---
title: The Focus Timer
---
# The Focus Timer

A timer for working in blocks, tied to the task you're on.

## Starting one

- On **Focus Now**, tap a task to open it, then tap **Focus on this**. Or press
  the **▶** at the end of its row.
- On a track's page, use **Start focus timer** in a task's ⋮ menu.
- Or use **Start focus** in the sidebar for a block that isn't about any
  particular task.

A small timer appears in the bottom-right corner of every page and keeps
running as you move around the app. The tab's title shows the clock too, so
you can see it from another tab. The task you're timing is marked
**Focusing** in Focus Now.

## What happens

1. **Focus**: 25 minutes by default. **Pause** and **Resume** freeze it
   exactly; **Stop** ends it early.
2. When the block ends, **nothing starts by itself.** A pop-up says the block
   is done and asks whether to **Start the 5-minute break** or **Skip the
   break**. The break begins when you tap, not before, because you may have put
   the phone down and walked away.
3. **Break**: 5 minutes by default. **Skip** ends it. When it ends you're told,
   and the timer goes away.

There is no beep. The pop-up is on screen until you answer it, and it is still
there if you come back to the app hours later (the break is only offered if the
block ended in the last half hour).

Both lengths are in **Settings → Focus timer**. They apply to the next block
you start, and are saved on that device.

## When the phone is on the desk

- **In the Android app**, the end of a block or a break is delivered as a
  **system notification**, even if the app is closed or the screen is off. The
  first time you start a timer, Android asks to allow notifications; say yes.
  Tapping the notification opens the app on the "start the break" pop-up.
- **In the browser or the installed web app**, the pop-up appears when you
  return. If the page is still open in the background, you also get a browser
  notification that stays until you click it. A closed browser tab can't be
  woken, so for a timer you'll walk away from, use the Android app.

The timer is based on clock time, not a counter, so a slow background tab
can't make it drift, and a block that ran out while the app was closed is
logged when you come back.

## What gets logged

A finished block logs its full length. Stopping early logs the whole minutes
you actually did (under a minute logs nothing). Time is logged against the
task, shown on its row next to the deadline, and on **Review**:

- **Focus, last 7 days** with the all-time total underneath, and
- **Where the time went**: the tasks the last week's blocks were spent on,
  with their tracks.

If you delete a task, the minutes you spent on it still count, just against
nothing.

Focus sessions are part of the JSON backup and restore. On Supabase, the
timer's log needs the latest \`supabase/setup.sql\` to have been run.
`,y=`---
title: On Your Phone
---
# On Your Phone

Waypoint works in any browser, installs like an app, and has an Android app.
This chapter covers getting it onto a phone, how it keeps itself up to date,
and the gestures.

## Installing

### Android: from the browser (recommended)

1. Open **waypoint.yudhvir.in** in Chrome.
2. Scroll to **Get the app** and tap **Install Waypoint**. If you don't see the
   button, open the **⋮ menu** and choose **Install app**.
3. Confirm. Waypoint appears on your home screen and opens full-screen.

There's no download, no security warning, and it updates itself.

### Android: the app file (APK)

1. On the same page, tap **Download the APK**, then open the file when it
   finishes.
2. If Android says it can't install from this source, tap **Settings** and
   allow installs from your browser, then go back.
3. If Play Protect warns about an unknown app, choose **Install anyway**.
4. Tap **Install**, then open Waypoint.

### iPhone and iPad

1. Open the site in **Safari** (not Chrome).
2. Tap **Share → Add to Home Screen → Add**.
3. Open it from your home screen.

### Computer

Open the site in any browser. In Chrome or Edge you can also use the install
icon in the address bar.

## Keeping it up to date

The website and the installed web app update themselves. The Android app has two
layers:

- **The app's screens and features** update quietly in the background. When you
  open the app online it checks, downloads what's new, and uses it the next time
  you open it.
- **The app itself** (rare) needs a new install file. When that happens a notice
  appears at the bottom of the screen and the download starts **by itself**,
  with a progress bar. When it finishes, Android shows its own
  "Do you want to update this app?" screen. Tap **Install**. That tap is
  Android's requirement for any app outside the Play Store; the app can't do it
  for you.

The first time, Android also asks you to allow Waypoint to install updates:
the notice has an **Open settings** button, you switch it on, and you come
back. You only do this once.

If you'd rather not update right now, tap **Not now**; it won't ask about that
version again. To check yourself, use **Settings → About → Check for
updates**. Your data stays through an update: it's the same app with the same
storage.

Before anything is installed the app checks the file against a fingerprint
published with the update and that it's really Waypoint, and Android refuses it
unless it was signed with the same key as the app you have.

## Gestures

On a phone the sidebar is a drawer:

- **Swipe right** from the left side of the screen to open it. It follows your
  finger, and settles open or shut depending on how far you went or how fast you
  flicked.
- **Swipe left** anywhere to close it, like drawing a curtain.
- The ☰ button in the corner does the same.

The swipe is ignored where it would get in the way: in text fields, inside the
note editor, and on anything that scrolls sideways, such as the activity grid.
Android's own back gesture lives at the very edge of the screen, so you can
start the swipe a little further in.

## If something doesn't work

- **No Install button on the site:** Chrome only offers it when the app isn't
  already installed. Use the ⋮ menu.
- **The update notice says it couldn't finish:** check your connection and tap
  **Try again**. A download that doesn't match its fingerprint is deleted
  rather than installed.
- **Google sign-in opens a browser and doesn't come back:** reinstall the app.
  Android verifies the link between the site and the app when it's installed.
`,b=`---
title: Setting Up Google Sign-In
---
# Setting Up Google Sign-In

Signing in with Google saves your tracks as one file in a "Waypoint" folder in
your own Google Drive. Like the Supabase option, this is one-time setup for
whoever is deploying the app — anyone who signs in afterward just clicks
"Sign in with Google", nothing more.

If you'd rather skip this, guest mode and Supabase both work without it.

## Why this needs more than an API key

Supabase's anon key is safe to put straight into the app because row-level
security does the actual protecting. Google's OAuth **client secret** is
different — anyone holding it could mint tokens as your app, so it can never
ship in the browser bundle. That's the one piece here that needs a server,
even though Waypoint otherwise has none: a small, stateless Supabase Edge
Function holds the secret and does nothing else. It stores no data of its
own — the refresh token it hands back is kept in the browser, in IndexedDB,
the same way a guest's tracks are.

## 1. Create a Google Cloud OAuth client

1. Go to [console.cloud.google.com](https://console.cloud.google.com) and
   create (or pick) a project.
2. **APIs & Services → Library** → enable the **Google Drive API**.
3. **APIs & Services → OAuth consent screen**:
   - User type: External (unless everyone using this is in your Google
     Workspace org).
   - Add the \`drive.file\` scope (per-file access only — the app can never
     see anything in your Drive besides what it creates itself) plus
     \`email\` and \`profile\`.
   - While in **Testing** status you can add up to 100 test users with no
     verification review needed — fine for personal or small-group use.
4. **APIs & Services → Credentials → Create Credentials → OAuth client ID**
   → **Web application**.
   - **Authorized JavaScript origins**: every origin the app runs on, e.g.
     \`https://waypoint.example.com\` and \`http://localhost:5173\`. Origin
     only — no path, no trailing slash.
   - **Authorized redirect URIs**: the full callback path on each of those
     same origins, e.g. \`https://waypoint.example.com/auth/google/callback\`
     and \`http://localhost:5173/auth/google/callback\`.
5. Copy the **Client ID** and **Client secret** from this credential.

## 2. Deploy the token-relay Edge Function

\`\`\`bash
supabase link --project-ref <your-project-ref>
supabase functions deploy google-token --no-verify-jwt
\`\`\`

\`--no-verify-jwt\` matters here: this function has to be callable before
anyone has a Supabase session (Drive sign-in doesn't require Supabase at
all), so Supabase's own gateway auth would only get in the way. The
function is safe to leave open — see its header comment in
\`supabase/functions/google-token/index.ts\` for why.

Set two secrets on whichever project you deployed it to (it doesn't need to
be the same project as your tracks/topics/tasks data — its only job is this
token exchange):

| Secret | Value |
| --- | --- |
| \`GOOGLE_CLIENT_ID\` | From step 1 |
| \`GOOGLE_CLIENT_SECRET\` | From step 1 — never put this one in the app itself |

## 3. Point the app at it

Set these as build-time env vars (e.g. in Vercel's project settings) —
both are safe to expose, same as \`VITE_SUPABASE_ANON_KEY\`:

\`\`\`bash
VITE_GOOGLE_CLIENT_ID=<the client id from step 1>
VITE_GOOGLE_TOKEN_RELAY_URL=https://<project-ref>.supabase.co/functions/v1/google-token
\`\`\`

Leave either unset and the "Sign in with Google" button shows as disabled
("Coming soon") instead of failing at sign-in time.

## What it looks like once it's live

Someone clicking "Sign in with Google" is sent to Google's consent screen,
then straight back into Waypoint signed in — no popups. Behind the scenes,
the app asked for offline access, so it holds onto a refresh token
(in IndexedDB, on that device) and quietly renews its access token through
the relay whenever the old one's about to expire, roughly once an hour.
There's nothing to re-authorize unless that refresh token itself is
revoked — from Google's side (myaccount.google.com → Security → Third-party
access) or by signing out in Waypoint.
`,x=i(),S=[{slug:`welcome`,raw:d},{slug:`connecting-your-supabase-project`,raw:f},{slug:`the-markdown-import-format`,raw:p},{slug:`search-review-and-repeating-tasks`,raw:m},{slug:`flashcards`,raw:h},{slug:`quick-add`,raw:g},{slug:`linking-notes`,raw:_},{slug:`focus-timer`,raw:v},{slug:`on-your-phone`,raw:y},{slug:`google-drive-setup`,raw:b}].map(({slug:e,raw:t})=>{let{title:n,body:r}=l(t);return{slug:e,title:n,html:c.parse(r,{async:!1})}});function C(){return(0,x.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,children:[(0,x.jsx)(`rect`,{x:`3`,y:`4`,width:`18`,height:`16`,rx:`2`}),(0,x.jsx)(`line`,{x1:`9`,y1:`4`,x2:`9`,y2:`20`})]})}function w(){let{hash:e}=o(),{backend:t}=n(),r=t?`/`:`/login`,[i,a]=(0,u.useState)(()=>window.innerWidth>=768),c=e?e.slice(1):S[0].slug,l=S.find(e=>e.slug===c)??S[0];return(0,u.useEffect)(()=>{window.scrollTo({top:0})},[c]),(0,x.jsxs)(`div`,{className:`mx-auto flex min-h-screen max-w-5xl`,children:[i&&(0,x.jsx)(`div`,{className:`fixed inset-0 z-40 bg-black/50 md:hidden`,onClick:()=>a(!1),"aria-hidden":`true`}),(0,x.jsx)(`aside`,{className:`fixed inset-y-0 left-0 z-50 w-72 overflow-hidden border-r border-border bg-card transition-transform duration-200 md:static md:z-auto md:translate-x-0 md:transition-[width] ${i?`translate-x-0 md:w-64`:`-translate-x-full md:w-0 md:translate-x-0 md:border-r-0`}`,children:(0,x.jsxs)(`div`,{className:`w-72 px-5 py-8 md:w-64`,children:[(0,x.jsxs)(`div`,{className:`flex items-center justify-between`,children:[(0,x.jsx)(`p`,{className:`text-xs font-semibold uppercase tracking-wider text-muted-foreground`,children:`Guide`}),(0,x.jsx)(`button`,{type:`button`,onClick:()=>a(!1),"aria-label":`Close chapter list`,className:`rounded-md p-1 text-muted-foreground hover:text-foreground md:hidden`,children:`✕`})]}),(0,x.jsx)(`nav`,{className:`mt-4 flex flex-col gap-0.5 text-sm`,children:S.map(e=>(0,x.jsx)(s,{to:`/guide#${e.slug}`,onClick:()=>a(window.innerWidth>=768),className:`rounded-md px-2 py-1.5 transition-colors ${e.slug===c?`bg-accent font-medium text-accent-foreground`:`text-muted-foreground hover:bg-accent hover:text-accent-foreground`}`,children:e.title},e.slug))})]})}),(0,x.jsxs)(`div`,{className:`min-w-0 flex-1 px-4 py-8 sm:px-8`,children:[(0,x.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,x.jsx)(`button`,{type:`button`,onClick:()=>a(e=>!e),"aria-label":i?`Hide chapter list`:`Show chapter list`,"aria-pressed":i,className:`flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-border text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground`,children:(0,x.jsx)(C,{})}),(0,x.jsx)(s,{to:r,className:`text-sm text-muted-foreground hover:underline`,children:`← Back to Waypoint`})]}),(0,x.jsx)(`div`,{className:`prose prose-sm mt-8 max-w-none dark:prose-invert`,dangerouslySetInnerHTML:{__html:l.html}},l.slug)]})]})}var T=[{slug:`welcome`,raw:d},{slug:`connecting-your-supabase-project`,raw:f},{slug:`the-markdown-import-format`,raw:p},{slug:`search-review-and-repeating-tasks`,raw:m},{slug:`flashcards`,raw:h},{slug:`quick-add`,raw:g},{slug:`linking-notes`,raw:_},{slug:`focus-timer`,raw:v},{slug:`on-your-phone`,raw:y},{slug:`google-drive-setup`,raw:b}].map(({slug:e,raw:t})=>{let{title:n,body:r}=l(t),i=c.parse(r,{async:!1}),a=/<p>([\s\S]*?)<\/p>/.exec(i)?.[1]??``;return{slug:e,title:n,html:i,summary:new DOMParser().parseFromString(a,`text/html`).body.textContent?.trim()??``}});function E(){return(0,x.jsx)(`div`,{"aria-hidden":`true`,className:`relative hidden h-72 items-center justify-center rounded-2xl bg-[#3a63c8] shadow-lg md:flex`,children:(0,x.jsxs)(`svg`,{viewBox:`0 0 400 240`,className:`h-full w-full p-6`,fill:`none`,stroke:`white`,strokeOpacity:`0.85`,strokeWidth:`1.5`,children:[(0,x.jsx)(`path`,{d:`M70 40h120v160H70z`}),(0,x.jsx)(`path`,{d:`M70 70h120M70 100h120M70 130h80`,strokeOpacity:`0.5`}),(0,x.jsx)(`path`,{d:`M210 60h110v130H210z`}),(0,x.jsx)(`path`,{d:`M225 85h80M225 110h80M225 135h50`,strokeOpacity:`0.5`}),(0,x.jsx)(`circle`,{cx:`330`,cy:`50`,r:`22`,fill:`white`,fillOpacity:`0.9`,stroke:`none`}),(0,x.jsx)(`path`,{d:`M190 120h20`,strokeDasharray:`3 4`}),(0,x.jsx)(`path`,{d:`m60 215 20-20 20 20`})]})})}function D(){let{ready:e,backend:t}=n();return e?t?(0,x.jsx)(w,{}):(0,x.jsx)(O,{}):null}function O(){let{hash:e}=o(),n=e?e.slice(1):``,i=T.find(e=>e.slug===n);return(0,u.useEffect)(()=>{window.scrollTo({top:0}),document.title=i?`${i.title} — Waypoint Guide`:`Guide — Waypoint`},[i]),(0,x.jsxs)(`div`,{className:`min-h-screen bg-background`,children:[(0,x.jsx)(t,{}),(0,x.jsx)(`section`,{className:`bg-[#f4f4f5] dark:bg-[#0b0b0b]`,children:(0,x.jsxs)(`div`,{className:`mx-auto grid max-w-6xl items-center gap-8 px-6 py-12 md:grid-cols-2 md:py-14`,children:[(0,x.jsxs)(`div`,{children:[(0,x.jsx)(`h1`,{className:`text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl`,children:i?i.title:`Guide`}),(0,x.jsx)(`p`,{className:`mt-5 text-lg`,children:i?`Waypoint guide`:`Learn how to set up and get the most out of Waypoint`})]}),(0,x.jsx)(E,{})]})}),(0,x.jsx)(`main`,{className:`mx-auto max-w-6xl px-6 py-14`,children:i?(0,x.jsxs)(`div`,{className:`grid gap-10 md:grid-cols-[14rem_1fr]`,children:[(0,x.jsxs)(`nav`,{className:`flex flex-col gap-1 text-sm md:sticky md:top-6 md:self-start`,children:[(0,x.jsx)(s,{to:`/guide`,className:`mb-2 font-semibold text-primary hover:underline`,children:`← All chapters`}),T.map(e=>(0,x.jsx)(s,{to:`/guide#${e.slug}`,className:`rounded-md px-2 py-1.5 ${e.slug===i.slug?`bg-accent font-medium text-accent-foreground`:`text-muted-foreground hover:text-foreground`}`,children:e.title},e.slug))]}),(0,x.jsx)(`article`,{className:`prose max-w-3xl dark:prose-invert prose-a:text-primary`,dangerouslySetInnerHTML:{__html:i.html}},i.slug)]}):(0,x.jsxs)(x.Fragment,{children:[(0,x.jsx)(`h2`,{className:`text-4xl font-extrabold tracking-tight`,children:`Chapters`}),(0,x.jsx)(`p`,{className:`mt-6 max-w-2xl text-xl leading-relaxed`,children:`Everything you need, from connecting your storage to importing existing notes. Each chapter stands on its own, so start wherever makes sense.`}),(0,x.jsx)(`div`,{className:`mt-10 grid gap-x-16 gap-y-10 md:grid-cols-2`,children:T.map(e=>(0,x.jsxs)(`div`,{children:[(0,x.jsx)(s,{to:`/guide#${e.slug}`,className:`text-base font-bold text-primary hover:underline`,children:e.title}),(0,x.jsx)(`p`,{className:`mt-3 text-sm leading-relaxed`,children:e.summary})]},e.slug))})]})}),(0,x.jsx)(r,{})]})}export{D as Guide};